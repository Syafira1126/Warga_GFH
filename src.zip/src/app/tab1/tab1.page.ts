import { Component, OnInit } from '@angular/core';
import {
  AlertController,
  LoadingController,
  NavController,
  ToastController,
  ModalController,
  ViewWillEnter
} from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
})
export class Tab1Page implements ViewWillEnter {
  public Warga: any;
  isMenuOpen = false;
  alertController: AlertController;

  constructor(
    private _apiService: ApiService,
    private toastCtrl: ToastController,
    private navCtrl: NavController,
    private router: Router,
    private storage: Storage,
    private alertCtrl: AlertController
  ) {
    this.getUser();
    this.alertController = alertCtrl;
  }

  ionViewWillEnter(): void {
    try {
      this.getUser();
    } catch (e) {
      throw new Error(e + 'Method not implemented.');
    }
  }

  async presentToast(msg: any, color: any, icon: any) {
    const toast = await this.toastCtrl.create({
      icon: icon,
      message: msg,
      duration: 1500,
      color: color,
      position: 'top',
    });
    toast.present();
  }

  async getUser() {
    await this.storage.create();
    this.storage.get('isLoggedIn').then(async (val) => {
      if (val == null) {
        this.presentToast(
          "You're not logged in, please login !",
          'danger',
          'alert-circle-outline'
        );
        this.navCtrl.navigateRoot('/login');
      } else {
        this._apiService.getWarga(val).then((res) => {
          if (res.msg == 'ok') {
            this.Warga = Array(res.data);
          } else if (res.msg == 'notAcive') {
            this.presentToast(
              'Account is not active !',
              'warning',
              'alert-circle-outline'
            );
            this.navCtrl.navigateRoot('/login');
          } else if (res.msg == 'err') {
            this.presentToast(
              'Something went wrong',
              'danger',
              'alert-circle-outline'
            );
          }
        });
      }
    });
  }

  paymentRoute(route: string) {
    this.navCtrl.navigateRoot([route]);
  }

  async logout() {
    const alert = await this.alertController.create({
      header: 'Konfirmasi',
      message: 'Apakah Anda yakin ingin keluar dari aplikasi?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
            // Batal
          },
        },
        {
          text: 'Yes',
          handler: () => {
            // Logout dan navigasi ke halaman login
            this.storage.remove('isLoggedIn');
            localStorage.removeItem('isLoggedIn');
            this.navCtrl.navigateRoot('/login');
          },
        },
      ],
    });

    await alert.present();
  }

  route(route:string){
    this.navCtrl.navigateForward(route);
  }
}
